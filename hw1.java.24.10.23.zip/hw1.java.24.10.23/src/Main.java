public class Main {
    public static void main(String[] args) {
        System.out.println(multi2(3, 3));
        System.out.println(multi3(2));
        System.out.println(multi4(2));

    }

    private static int multi2(int num1, int num2) {
        int m2 = num1 * num2;
        return m2;

    }

    private static int multi3(int num3) {
        int m3 = multi2(3, 7) * num3;
        return m3;


    }

    private static int multi4(int num4) {
        int m4 = multi3(2) * num4;
        return m4;
    }
}


/*Сделайте перегруженные методы для перемножения 2-х, 3-х и 4-х чисел.
В методе умножения 3-х чисел используйте вызов метода для 2-х чисел.
В методе умножения 4-х чисел – вызов метода для 3-х чисел.*/