import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("Введите Ваше число ");
        Scanner scr = new Scanner(System.in);
        int n = scr.nextInt();
        System.out.println("Факториала числа равен - " + getFact(n));


    }

    public static int getFact(int n) {
        if (n <= 1) {
            return 1;
        } else {
            return n * getFact(n - 1);
        }
    }
}
/*Используя рекурсию, написать метод вычисления факториала числа n (n!), вводимого с клавиатуры.*/