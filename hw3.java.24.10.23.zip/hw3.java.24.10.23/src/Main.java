import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        int[] homeWork = new int[8];
        for (int i = 0; i < homeWork.length; i++) {
            homeWork[i] = (int) (1 + Math.random() * 50);
        }
        System.out.println(Arrays.toString(homeWork));
        for (int i = 0; i < homeWork.length; i++) {
           // if (i == 0){
             //   homeWork[i] = 0;
           // }
            if (i % 2 == 1) {
                homeWork[i] = 0;
            }
        }
        System.out.println(Arrays.toString(homeWork));
        Arrays.sort(homeWork);
        System.out.println(Arrays.toString(homeWork));
        }

        }




/*Создайте массив из 8 случайных целых чисел из интервала [1;50]
Выведите массив в консоль в строку.
Замените каждый элемент с нечетным индексом на ноль.
Снова выведете массив в консоль в отдельной строке.
Отсортируйте массив по возрастанию.
Снова выведете массив в консоль в отдельной строке.*/