import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        String[] homeWork = {"Строка вававававодин", "Стр", "Строка три", "Строка четыре", "Строка 5"};
        int max = 0;
        int min = Integer.MAX_VALUE;
        for (int i = 0; i < homeWork.length; i++) {
            if (homeWork[i].length()>max){
                max = homeWork[i].length();
            }
        }
        for (int i = 0; i < homeWork.length; i++) {
            if(homeWork[i].length() == max){
                System.out.println("Строка с наибольшим количеством строк - "+homeWork[i]);
            }
        }
        for (int i = 0; i < homeWork.length; i++) {
            if (homeWork[i].length()<min){
                min = homeWork[i].length();
            }
        }
        for (int i = 0; i < homeWork.length; i++) {
            if(homeWork[i].length() == min){
                System.out.println("Строка с наименьшим количеством строк - "+homeWork[i]);

            }

        }

    }
}
/*Создайте массив из 5 строк. Используя метод length() строк,
найдите строку с наибольшей длиной и строк с наименьшей длиной.
Выведите массив и полученный строки в консоль.*/